﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Windows.Input;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using ExampleCollectionView.Base;
using ExampleCollectionView.Models;
using System.Reactive.Subjects;

namespace ExampleCollectionView.ViewModels
{
	public class ExampleViewModel : ObservableObject
	{

		private CancellationTokenSource _throttleCts = new CancellationTokenSource();


		public ObservableRangeCollection<ExampleGroup> Items { get; set; } = new ();

		private List<ExampleGroup>? _cachedItems;

		public string? SearchTerm { get; set; }


		public void Initialization()
		{
			CreateCollection();
		}

		public void Search(string? text)
		{
			// Items.Clear();
			_ = DebouncedSearch();
		}

		private async void CreateCollection()
		{
			// create cache data
			var exams = await Task.Run(() =>
			   {
				   List<string> groups = ["A", "B", "C"];
				   List<ExampleGroup> exams = [];
				   foreach (string group in groups)
				   {
					   List<Example> examples = [];
					   var groupName = group;
					   if (groupName == "A")
					   {
						   groupName = "Alexander";
					   }
					   else if (groupName == "B")
					   {
						   groupName = "BExample";
					   }
					   for (int index = 0; index <= 50; index++)
					   {
						   examples.Add(new Example
						   {
							   Name = $"{groupName}{index}"
						   });
					   }
					//    Items.Add(new ExampleGroup(groupName, examples));
					   exams.Add(new ExampleGroup(groupName, examples));
				   }
				   return exams;
			   });
			_cachedItems = exams;
			Items.AddRange(exams);

		}

		private int binarySearch(int[] arr, int x)
		{
			int l = 0, r = arr.Length - 1;
			while (l <= r)
			{
				int m = l + (r - l) / 2;

				// Check if x is present at mid
				if (arr[m] == x)
					return m;

				// If x greater, ignore left half
				if (arr[m] < x)
					l = m + 1;

				// If x is smaller, ignore right half
				else
					r = m - 1;
			}

			// If we reach here, then element was
			// not present
			return -1;
		}

		private async Task FilterSearch()
		{
			if (tmpString != SearchTerm)
			{
				// Items.Clear();
				tmpString = "";
				tmpString = SearchTerm;
				// Filter cached data.
				var exams = await Task.Run(() =>
				{
					var Term = SearchTerm ?? "";
					var items = (_cachedItems ?? []).Select((res) =>
					{
						var filters = res.Where((e) => e.Name.Contains(Term)).ToList();
						Console.WriteLine("texxt serrr =>{0}", filters);
						return new ExampleGroup(res.Key, filters);
					}).Where((res) => res.Count > 0);

					return items;
				});

				Items.ReplaceRange(exams);
				// Items.Clear();
				// Items.AddRange(exams);

				// foreach (ExampleGroup e in exams)
				// {
				// 	Console.WriteLine("vvv, {0}", e);
				// 	Items.Add(e);
				// }
			}

		}

		string tmpString = "";
		private async Task DebouncedSearch()
		{
			// try
			// {
			// 	await Task.Delay(TimeSpan.FromMilliseconds(150), _throttleCts.Token)
			// 	.ContinueWith(async task => await FilterSearch(),
			// 		CancellationToken.None,
			// 		TaskContinuationOptions.OnlyOnRanToCompletion,
			// 		TaskScheduler.FromCurrentSynchronizationContext());
			// }
			// catch
			// {
			// 	Console.WriteLine("error");
			// }
			try
			{
				DebounceDispatcher debounceDispatcher = new DebounceDispatcher();
				debounceDispatcher.Throttle(300, async _ => await FilterSearch());
			}
			catch
			{
				Console.WriteLine("error");
			}

		}

	}
}

